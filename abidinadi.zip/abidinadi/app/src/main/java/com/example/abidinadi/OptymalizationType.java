package com.example.abidinadi;

public enum  OptymalizationType {
    DISTANCE, TIME
}
